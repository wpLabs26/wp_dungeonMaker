# Frozen Crypt v1 — Unity / WP Dungeon map set

This pack adds eight **actual 1024×1024 PNG base-color textures**, a complete manifest copied and retargeted from Worn Dungeon v1, and a merged catalog preserving Worn Dungeon as the default. It does **not** contain completed 3D meshes or Unity prefabs.

## Installation
1. Back up the working project. Copy `assets/map-sets/frozen-crypt-v1` into the existing `Assets/map-sets` directory (match the project's actual case and layout).
2. Merge the `frozen-crypt` entry into the existing catalog; do not overwrite any newer catalog with the included snapshot.
3. In Unity, import textures as sRGB base-color, Repeat, max size 1024. Create materials for the eight IDs.
4. Resolve `{"id":"frozen-crypt","version":1}` through the catalog, reuse the **same existing geometry/prefab keys** and wall rotation rules.
5. Load `examples/Frozen_Crypt_Test.wpdungeon` on PC first, then Quest. Do not change working scenes or map format.

## Important limits
- Texture art is derived from the user's original Worn Dungeon base-color PNGs with a cold tint, snow/frost overlays, and cracked ice treatment. These are **first-pass playable surfaces**, not hand-painted production seamless/PBR textures. Inspect repeat seams and UVs in Unity.
- Frozen water is **visual only**: retain existing water collision / no-walk behavior.
- No mesh/prefab files are included. The following are **design targets for new decoration prefabs**, not assets claimed to exist: icicle curtain (web replacement), broken snow-covered barrel, split snow-covered crate, frozen roots, jagged ice crystal, frozen bones, three opaque/cloudy ice pillars with indistinct sinister silhouettes. Build as static low-poly meshes with baked textures and avoid realtime transparent overdraw on Quest.
- Existing decoration identifiers and object mapping remain unchanged. Add any new visual variants without changing dungeon JSON semantics.
- Do not edit the original Worn Dungeon folder, original maps, or existing working scenes.

## QA
Check catalog resolution, every wall orientation, UV tiling, door orientation, decorations, frozen-water collision, floor/wall gaps, and performance on Quest 3S.
